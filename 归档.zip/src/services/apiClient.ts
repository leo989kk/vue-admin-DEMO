// src/services/apiClient.ts
import { router } from "@/router";
import { useAppStore } from "@/stores/app";
import { useAuthStore } from "@/stores/auth";
import type { ApiError, ApiResponse } from "@/types/api";
import axios, { AxiosError } from "axios";
import { ElMessage } from "element-plus";

// 你可以先写死，后面改成 import.meta.env.VITE_API_BASE_URL
const BASE_URL = "/api";

/**
 * axios 实例：所有请求都从这里走
 */
export const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
});

// ===== 请求拦截：带 token + 开启 loading =====
apiClient.interceptors.request.use(
  (config) => {
    const auth = useAuthStore();
    const app = useAppStore();

    // 开启全局 loading（你也可以做白名单：某些请求不计入）
    app.startLoading();

    // 自动带 token（如果有）
    if (auth.token) {
      config.headers = config.headers ?? {};
      config.headers.Authorization = `Bearer ${auth.token}`;
    }

    return config;
  },
  (error) => Promise.reject(error),
);

// ===== 响应拦截：关闭 loading + 统一错误处理 =====
apiClient.interceptors.response.use(
  (response) => {
    const app = useAppStore();
    app.stopLoading();

    // 这里先直接返回 response.data
    return response;
  },
  async (error: AxiosError) => {
    const app = useAppStore();
    app.stopLoading();

    const auth = useAuthStore();

    // HTTP 层错误
    const status = error.response?.status;

    // 401：未登录/登录过期
    if (status === 401) {
      auth.logout();
      // 带 redirect：登录后回到原页面
      const redirect = router.currentRoute.value.fullPath;
      await router.replace({ path: "/login", query: { redirect } });

      // 给个提示（可选）
      ElMessage.warning("登录已过期，请重新登录");
      return Promise.reject<ApiError>({
        message: "Unauthorized",
        status,
      });
    }

    // 403：已登录但无权限
    if (status === 403) {
      await router.replace("/403");
      ElMessage.error("无权限访问");
      return Promise.reject<ApiError>({
        message: "Forbidden",
        status,
      });
    }

    // 其他网络错误/超时
    const msg = error.message || "网络错误";
    ElMessage.error(msg);

    return Promise.reject<ApiError>({
      message: msg,
      status,
    });
  },
);

/**
 * 业务层：把 ApiResponse<T> 变成 T
 * - success=false 或 code != "1" 时抛错
 */
export function unwrapData<T>(res: ApiResponse<T>): T {
  if (!res.success) {
    throw { message: res.msg || "请求失败", code: res.code } as ApiError;
  }
  // 你们如果以 code==="1" 代表成功，可以加这一条
  if (res.code !== "1") {
    throw { message: res.msg || "请求失败", code: res.code } as ApiError;
  }
  return res.data;
}
