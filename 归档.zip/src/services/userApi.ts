// src/services/userApi.ts
import type { ApiResponse } from "@/types/api";
import { apiClient, unwrapData } from "./apiClient";

export type User = {
  id: number;
  name: string;
};

// 示例：获取用户列表
export async function getUsers(): Promise<User[]> {
  // 这里假设后端返回 ApiResponse<User[]>
  const resp = await apiClient.get<ApiResponse<User[]>>("/users");
  return unwrapData(resp.data);
}
