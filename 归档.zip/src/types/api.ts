export type ApiSuccessResponse<T> = {
  success: true;
  data: T;
  code?: string;
  msg?: string;
  status?: number;
};

export type ApiFailureResponse = {
  success: false;
  code?: string;
  msg?: string;
  status?: number;
};

export type ApiResponse<T> = ApiSuccessResponse<T> | ApiFailureResponse;

export type ApiError = {
  message: string;
  code?: string;
  status?: number;
};
