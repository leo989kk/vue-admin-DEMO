// src/stores/app.ts
import { defineStore } from "pinia";

export const useAppStore = defineStore("app", {
  state: () => ({
    loadingCount: 0, // 计数器：>0 表示有请求进行中
  }),
  getters: {
    isLoading: (s) => s.loadingCount > 0,
  },
  actions: {
    startLoading() {
      this.loadingCount++;
    },
    stopLoading() {
      this.loadingCount = Math.max(0, this.loadingCount - 1);
    },
    resetLoading() {
      this.loadingCount = 0;
    },
  },
});
