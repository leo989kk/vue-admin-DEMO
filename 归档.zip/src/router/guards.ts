// src/router/guards.ts
import { useAuthStore } from "@/stores/auth";
import { useUserStore } from "@/stores/user";
import type { Router } from "vue-router";

/**
 * 在这里统一注册路由守卫
 * - 未登录访问需要登录的页面 => 跳转到 /login，并携带 redirect
 * - 已登录访问 /login => 直接回首页
 */
export function setupRouterGuards(router: Router) {
  router.beforeEach(async (to) => {
    const title = (to.meta.title as String | undefined) ?? "";
    document.title = title ? `${title} - Vue Admin Pro` : "Vue Admin Pro";

    const auth = useAuthStore();
    const user = useUserStore();

    const isPublic = Boolean(to.meta.public);
    const requiresAuth = Boolean(to.meta.requiresAuth);

    // 1) 已登录还去登录页：不允许（避免重复登录）
    if (to.path === "/login" && auth.isAuthed) {
      return { path: "/" };
    }

    // 2) 公开页面：允许访问
    if (isPublic) return true;

    // 3) 需要登录的页面：没登录就拦截
    if (requiresAuth && !auth.isAuthed) {
      return {
        path: "/login",
        query: { redirect: to.fullPath }, // 记录原本想去哪里
      };
    }

    // 4) 到这里说明：要么不需要登录，要么已经登录
    //    如果已登录且访问的是后台页，我们先确保权限已加载
    if (auth.isAuthed) {
      await user.loadPermissions();
    }

    // 5) 路由级权限校验：
    //    约定：meta.permissions 是 string[]，只要满足“任意一个”就允许（你也可改成“全部满足”）
    const perms = (to.meta.permissions as string[] | undefined) ?? [];
    if (perms.length > 0) {
      const ok = user.hasAnyPermission(perms);
      if (!ok) {
        return { path: "/403" };
      }
    }

    // 4) 其他情况：放行
    return true;
  });
}
