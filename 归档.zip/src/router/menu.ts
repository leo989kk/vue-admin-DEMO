import { useUserStore } from "@/stores/user";
import type { RouteRecordRaw } from "vue-router";

export type MenuItem = {
  path: string;
  title: string;
  icon?: string;
};

/**
 * 判断某路由对当前用户是否可见（用于菜单）
 * 规则与路由守卫保持一致：
 * - meta.title 必须存在（否则不做菜单）
 * - meta.hidden=true 则不出现在菜单
 * - meta.permissions 存在则要求用户具备任意一个权限点
 */
function canShowInMenu(route: RouteRecordRaw): boolean {
  const user = useUserStore();
  const meta = (route.meta ?? {}) as any;

  const title = meta.title as string | undefined;
  if (!title) return false;

  // ✅ 隐藏页：不出现在菜单（但不代表无权限）
  if (meta.hidden === true) return false;

  const perms = (meta.permissions as string[] | undefined) ?? [];
  if (perms.length === 0) return true;

  return user.hasAnyPermission(perms);
}

export function buildMenuFromRoutes(
  allRoutes: readonly RouteRecordRaw[]
): MenuItem[] {
  const layout = allRoutes.find((r) => r.path === "/");
  const children = layout?.children ?? [];

  const menu: MenuItem[] = [];

  for (const r of children) {
    if (!canShowInMenu(r)) continue;

    const meta = (r.meta ?? {}) as any;
    const title = meta.title as string;
    const icon = meta.icon as string | undefined;

    const path = r.path ? `/${r.path}` : "/";
    menu.push({ path, title, icon });
  }

  return menu;
}
