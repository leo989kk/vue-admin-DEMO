import {
  createRouter,
  createWebHashHistory,
  type RouteRecordRaw,
} from "vue-router";

import AppLayout from "@/layouts/AppLayout.vue";
import ForbiddenPage from "@/pages/ForbiddenPage.vue";
import HomePage from "@/pages/HomePage.vue";
import LoginPage from "@/pages/LoginPage.vue";
import NotFoundPage from "@/pages/NotFoundPage.vue";
import UserDetailPage from "@/pages/UserDetailPage.vue";
import UserListPage from "@/pages/UserListPage.vue";
const routes: RouteRecordRaw[] = [
  {
    path: "/login",
    name: "login",
    component: LoginPage,
    meta: { public: true }, // public=true 表示公开路由
  },
  {
    path: "/404",
    name: "notFound",
    component: NotFoundPage,
    meta: {
      public: true,
      title: "404",
    },
  },
  {
    path: "/403",
    name: "forbidden",
    component: ForbiddenPage,
    meta: {
      public: true,
      title: "403",
    },
  },

  {
    path: "/",

    component: AppLayout,
    children: [
      {
        path: "",
        name: "home",
        component: HomePage,
        meta: {
          requiresAuth: true,
          title: "首页",
          icon: "House",
          permissions: ["dashboard:view"],
        },
      },
      {
        path: "users",
        // ✅ 注意：这里不再直接用 UserListPage 当 component
        //    而是用一个“占位容器”，让 children 可以嵌套出 matched 链路
        component: { template: "<router-view />" },
        meta: {
          requiresAuth: true,
          title: "用户管理",
          icon: "User",
          permissions: ["user:list"],
        },
        children: [
          // ✅ 列表页：/users
          {
            path: "",
            name: "users",
            component: UserListPage,
            meta: {
              requiresAuth: true,
              title: "", // 面包屑第 1 级就来自这里（也可只放父 meta.title）
              icon: "User",
              permissions: ["user:list"],
            },
          },

          // ✅ 详情页：/users/:id（隐藏菜单，但仍受权限控制）
          {
            path: ":id",
            name: "userDetail",
            component: UserDetailPage,
            meta: {
              requiresAuth: true,
              title: "用户详情",
              hidden: true,
              permissions: ["user:list"],
            },
          },
        ],
      },
    ],
  },
  {
    path: "/:pathMatch(.*)*",
    redirect: "/404",
    meta: { public: true },
  },
];
export const router = createRouter({
  history: createWebHashHistory(),
  routes,
});
