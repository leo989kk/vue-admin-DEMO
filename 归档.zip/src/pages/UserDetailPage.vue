<template>
  <div>
    <h2>用户详情</h2>
    <el-descriptions border :column="1">
      <el-descriptions-item label="User ID">{{ id }}</el-descriptions-item>
    </el-descriptions>

    <el-button style="margin-top: 16px" @click="goBack">返回</el-button>
  </div>
</template>

<script setup lang="ts">
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();

const id = route.params.id;

function goBack() {
  router.back();
}
</script>
