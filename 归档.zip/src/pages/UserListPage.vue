<template>
  <div>
    <h2>用户管理</h2>

    <el-space wrap>
      <!-- 只有有 user:create 权限才显示 -->
      <el-button type="primary" v-permission="['user:create']">
        新建用户
      </el-button>

      <!-- 只有有 user:edit 权限才显示 -->
      <el-button type="warning" v-permission="['user:edit']">
        编辑用户
      </el-button>

      <!-- 任意人可见 -->
      <el-button>普通按钮</el-button>
    </el-space>

    <el-divider />

    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="id" label="ID" width="120" />
      <el-table-column prop="name" label="姓名" />
      <el-table-column label="操作" width="240">
        <template #default>
          <el-button size="small" v-permission="['user:edit']">编辑</el-button>
          <el-button size="small" type="danger" v-permission="['user:delete']">
            删除（默认无权限）
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-alert
      v-if="errorText"
      type="warning"
      :closable="false"
      :title="`接口未接通，已使用本地数据：${errorText}`"
      style="margin: 12px 0"
    />
  </div>
</template>

<script setup lang="ts">
import { getUsers, type User } from "@/services/userApi";
import { onMounted, ref } from "vue";

const tableData = ref<User[]>([]);
const errorText = ref("");

onMounted(async () => {
  try {
    tableData.value = await getUsers();
  } catch (e: any) {
    errorText.value = e?.message || "加载失败";
    // 临时 fallback（等你接上后端就删掉）
    tableData.value = [];
  }
});
</script>

<style scoped></style>
