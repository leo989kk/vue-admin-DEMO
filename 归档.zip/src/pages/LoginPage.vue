<!-- src/pages/LoginPage.vue -->
<template>
  <div class="login-page">
    <el-card class="login-card">
      <template #header>
        <div class="login-title">登录</div>
      </template>

      <!-- Element Plus 表单 -->
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="80px"
        @keyup.enter="onSubmit"
      >
        <el-form-item label="账号" prop="username">
          <el-input v-model="form.username" placeholder="请输入账号" />
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            type="password"
            show-password
            placeholder="请输入密码"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="submitting"
            @click="onSubmit"
            style="width: 100%"
          >
            登录
          </el-button>
        </el-form-item>
      </el-form>

      <el-text type="info" size="small">
        说明：目前是 Mock 登录，任何账号密码都能进。
      </el-text>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { useAuthStore } from "@/stores/auth";
import type { FormInstance, FormRules } from "element-plus";
import { reactive, ref } from "vue";
import { useRoute, useRouter } from "vue-router";

// 表单实例（用于触发表单校验）
const formRef = ref<FormInstance>();

// 表单数据（响应式对象）
const form = reactive({
  username: "",
  password: "",
});

// Element Plus 表单校验规则
const rules: FormRules = {
  username: [{ required: true, message: "请输入账号", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }],
};

const submitting = ref(false);

const router = useRouter();
const route = useRoute();
const auth = useAuthStore();

/**
 * Mock 登录逻辑：
 * 1) 校验表单
 * 2) 生成一个假 token（真实项目里这里会调后端登录接口）
 * 3) 写入 authStore
 * 4) 跳转到登录前想去的页面（如果有 redirect），否则回首页
 */
async function onSubmit() {
  if (!formRef.value) return;

  // 触发表单校验
  const valid = await formRef.value.validate().catch(() => false);
  if (!valid) return;

  submitting.value = true;
  try {
    // mock token：用当前时间戳随便拼一个
    const mockToken = `mock_${Date.now()}`;

    auth.login(mockToken);

    // 如果路由上带了 redirect 参数，就跳回去；否则跳首页
    const redirect = (route.query.redirect as string) || "/";
    await router.replace(redirect);
  } finally {
    submitting.value = false;
  }
}
</script>

<style scoped>
.login-page {
  height: 100vh;
  display: grid;
  place-items: center;
  background: var(--el-fill-color-lighter);
}

.login-card {
  width: 420px;
}

.login-title {
  font-weight: 700;
  font-size: 16px;
}
</style>
