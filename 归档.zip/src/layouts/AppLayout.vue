<template>
  <!-- 整个应用的容器组件 -->
  <el-container class="app-shell">
    <!-- 左侧菜单 -->
    <el-aside class="app-aside" width="220px">
      <div class="brand">Vue Admin Pro</div>

      <el-menu :default-active="activeMenu" class="app-menu" router>
        <el-menu-item v-for="item in menu" :key="item.path" :index="item.path">
          <el-icon v-if="item.icon">
            <component :is="icons[item.icon]" />
          </el-icon>
          <span>{{ item.title }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <!-- 右侧内容 -->
    <el-container>
      <el-header class="app-header" height="56px">
        <div class="header-left">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item v-for="(m, idx) in breadcrumbs" :key="idx">
              {{ m }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="header-right">
          <el-tag v-if="appStore.isLoading" type="info">Loading...</el-tag>
          <el-button type="primary" size="small" @click="onLogout"
            >退出</el-button
          >
        </div>
      </el-header>

      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { useAuthStore } from "@/stores/auth";
import { computed } from "vue";
import { useRoute, useRouter } from "vue-router";

// ✅ 从路由表生成菜单
import { router as appRouter } from "@/router";
import { buildMenuFromRoutes } from "@/router/menu";
import { useAppStore } from "@/stores/app";
import { useUserStore } from "@/stores/user";
const appStore = useAppStore();
const user = useUserStore();

// ✅ Element Plus Icons：按需引入你路由 meta 里用到的 icon
import { House, User } from "@element-plus/icons-vue";

const route = useRoute();
const router = useRouter();
const auth = useAuthStore();

// 当前激活菜单
const activeMenu = computed(() => route.path);

// icon 映射表：meta.icon 用字符串，这里映射到真实组件
const icons: Record<string, any> = {
  House,
  User,
};

// 生成菜单（按权限过滤）
const menu = computed(() => buildMenuFromRoutes(appRouter.options.routes));

function onLogout() {
  auth.logout();
  router.replace("/login");

  user.reset();
}
const breadcrumbs = computed(() => {
  // route.matched 是从父到子的路由记录数组
  // 我们只取有 title 的部分作为面包屑
  return route.matched
    .map((r) => r.meta.title as string | undefined)
    .filter(Boolean) as string[];
});
</script>
<style scoped>
.app-shell {
  height: 100vh;
}

.app-aside {
  border-right: 1px solid var(--el-border-color);
  background: var(--el-bg-color);
}

.brand {
  height: 56px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-weight: 700;
  border-bottom: 1px solid var(--el-border-color);
}

.app-menu {
  border-right: none;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid var(--el-border-color);
  background: var(--el-bg-color);
}

.app-main {
  background: var(--el-fill-color-lighter);
  padding: 16px;
}
</style>
