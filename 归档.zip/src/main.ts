import { createApp } from "vue";
import App from "./App.vue";

import { router } from "@/router";
import { pinia } from "@/stores";

import ElementPlus from "element-plus";
import "element-plus/dist/index.css";

import { setupRouterGuards } from "@/router/guards";

const app = createApp(App);

app.use(pinia);
app.use(router);
app.use(ElementPlus);

setupRouterGuards(router);

app.mount("#app");
