import vue from "@vitejs/plugin-vue";
import path from "path";
import { defineConfig, type Plugin } from "vite";

function mockApiPlugin(): Plugin {
  return {
    name: "mock-api-plugin",
    configureServer(server) {
      // 让服务端能读取 JSON body（用于模拟登录等）
      server.middlewares.use((req, res, next) => {
        // 只处理 /api 开头
        if (!req.url?.startsWith("/api")) return next();

        // 统一设置返回为 JSON
        res.setHeader("Content-Type", "application/json; charset=utf-8");
        next();
      });

      // ====== /api/users：返回用户列表 ======
      server.middlewares.use("/api/users", (req, res, next) => {
        // 这里只处理 GET
        if (req.method !== "GET") return next();

        // ✅ 模拟 401/403（你可以通过 query 控制）
        // 访问 /api/users?status=401 或 /api/users?status=403
        const url = new URL(req.url!, "http://localhost");
        const status = url.searchParams.get("status");

        if (status === "401") {
          res.statusCode = 401;
          res.end(JSON.stringify({ message: "Unauthorized" }));
          return;
        }

        if (status === "403") {
          res.statusCode = 403;
          res.end(JSON.stringify({ message: "Forbidden" }));
          return;
        }

        // ✅ 正常成功返回（按你 unwrapData 的约定：success=true 且 code="1"）
        res.statusCode = 200;
        res.end(
          JSON.stringify({
            success: true,
            code: "1",
            msg: null,
            data: [
              { id: 1, name: "Alice" },
              { id: 2, name: "Bob" },
              { id: 3, name: "Charlie" },
            ],
          }),
        );
      });
    },
  };
}

export default defineConfig({
  plugins: [vue(), mockApiPlugin()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
